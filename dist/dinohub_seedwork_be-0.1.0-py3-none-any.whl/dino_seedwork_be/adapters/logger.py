import logging

LOG_FORMAT = (
    "%(levelname) -10s %(asctime)s %(name) -30s %(funcName) "
    "-35s %(lineno) -5d: %(message)s"
)

SIMPLE_LOGGER = logging.getLogger(__name__)
