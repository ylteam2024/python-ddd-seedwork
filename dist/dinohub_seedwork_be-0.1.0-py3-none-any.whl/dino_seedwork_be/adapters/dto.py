from dataclasses import dataclass


@dataclass
class DTO:
    pass
