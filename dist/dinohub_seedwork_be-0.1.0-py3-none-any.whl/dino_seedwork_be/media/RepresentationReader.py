from src.seedwork.media.AbstractJsonMediaReader import AbstractJSONMediaReader


class RepresentationReader(AbstractJSONMediaReader):
    pass
