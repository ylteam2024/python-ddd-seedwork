from src.seedwork.domain.assertion_concern import DomainAssertionConcern
from src.seedwork.domain.entities import Entity


class Aggregate(Entity, DomainAssertionConcern):
    ...
