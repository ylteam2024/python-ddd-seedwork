def toList(listLike):
    # print("listLike", listLike, [*listLike])
    return [*listLike]
