# DINO hub seedwork

This is a package contains
  * DDD (Domain Driven Design) artifact
  * Functional programming with Returns
  * Basic helpers function
