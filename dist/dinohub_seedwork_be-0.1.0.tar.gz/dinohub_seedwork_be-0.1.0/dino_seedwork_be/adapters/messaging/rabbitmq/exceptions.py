from src.seedwork.exceptions import MainException


class MessageException(MainException):
    pass
